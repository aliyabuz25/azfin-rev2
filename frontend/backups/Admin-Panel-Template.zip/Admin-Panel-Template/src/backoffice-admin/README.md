This directory will house the backoffice admin panel, reusing /admin page or a new interface.
